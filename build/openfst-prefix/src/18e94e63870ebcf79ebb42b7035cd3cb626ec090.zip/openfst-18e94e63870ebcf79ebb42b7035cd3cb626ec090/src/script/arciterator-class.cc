// Copyright 2005-2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the 'License');
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an 'AS IS' BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// See www.openfst.org for extensive documentation on this weighted
// finite-state transducer library.

#include <fst/script/arciterator-class.h>

#include <fst/script/script-impl.h>

namespace fst {
namespace script {

ArcIteratorClass::ArcIteratorClass(const FstClass &fst, int64 s)
    : impl_(nullptr) {
  InitArcIteratorClassArgs args(fst, s, this);
  Apply<Operation<InitArcIteratorClassArgs>>("InitArcIteratorClass",
                                             fst.ArcType(), &args);
}

MutableArcIteratorClass::MutableArcIteratorClass(MutableFstClass *fst, int64 s)
    : impl_(nullptr) {
  InitMutableArcIteratorClassArgs args(fst, s, this);
  Apply<Operation<InitMutableArcIteratorClassArgs>>(
      "InitMutableArcIteratorClass", fst->ArcType(), &args);
}

REGISTER_FST_OPERATION_3ARCS(InitArcIteratorClass, InitArcIteratorClassArgs);

REGISTER_FST_OPERATION_3ARCS(InitMutableArcIteratorClass,
                             InitMutableArcIteratorClassArgs);

}  // namespace script
}  // namespace fst
